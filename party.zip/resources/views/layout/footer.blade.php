<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
  <p class="text-muted mb-1 mb-md-0">Car Come .  </p>
  <p class="text-muted">made by <a href="https://www.pixllmall.com" target="_blank">pixll mall</a> <i class="mb-1 text-primary ms-1 icon-sm" data-feather="heart"></i></p>
</footer>